<?php

namespace App\Http\Controllers\Admin\Account;

use App\Helpers\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin\membermaster;
use App\Models\Admin\accountmaster;
use App\Models\Admin\ddcollection;
use App\Models\Admin\rdcollection;
use App\Models\Admin\eomaster;
use App\Models\Admin\ddwithdrawal;
use App\Models\Admin\mdwithdrawal;
use App\Models\Admin\atcbhd08;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use PDF;


class AccountController extends Controller
{
    public function index()
    {

        $member=membermaster::select('MemberId', 'MemberName')->get();
        $eomaster=eomaster::select('EOId', 'EOName')->get();
        $nextacno=accountmaster::selectRaw("max(cast(substr(trim(AccountNo),1) AS UNSIGNED))+1 as nextacno")
        ->first();
        $type = "D";
        return view('Account.index',compact('member','eomaster', 'nextacno','type'));
    }

    public function indexm()
    {
        $member = membermaster::select('MemberId', 'MemberName')->get();
        $eomaster = eomaster::select('EOId', 'EOName')->get();
        $nextacno = accountmaster::selectRaw("max(cast(substr(trim(AccountNo),1) AS UNSIGNED))+1 as nextacno")
        ->first();

        $type="M";
        return view('Account.index', compact('member', 'eomaster', 'nextacno','type'));
    }

    public function mdaccountlist()
    {
        $accountrecs=accountmaster::where('AType','=','MD')->paginate(100);
        //dd($accountrecs);
        $total = accountmaster::where('AType', '=', 'MD')->count();
        return view("admin.account.index",compact('accountrecs','total'));

    }

    public function ddaccountlist()
    {
        $accountrecs = accountmaster::where('AType','=','DD')->orderBy(\DB::raw('CAST(AccountNo as UNSIGNED)', "ASC"))->paginate(100);
       // dd($accountrecs);
        $total = accountmaster::where('AType', '=', 'DD')->count();
        return view("admin.account.index", compact('accountrecs', 'total'));
    }



    public function ddaccountlistindiv(Request $request)
    {
        $accountrecs = accountmaster::where('AType', '=', 'DD')->where('accountno',$request->memid)
        ->orWhere('accountid', $request->memid)->first();
        //dd($accountrecs);
        $total = accountmaster::where('AType', '=', 'DD')->count();
        return view("admin.account.indexindiv", compact('accountrecs', 'total'));
    }

    public function mdcollection()
    {
        $mdaccount = accountmaster::where('AType', '=', 'MD')->paginate(100);
        //dd($accountrecs);
        $total = accountmaster::where('AType', '=', 'MD')->count();
        return view("admin.account.mdcollection", compact('mdaccount', 'total'));
    }

    public function ddcollection()
    {
        $ddaccount=accountmaster::where('AType', '=', 'DD')->get();
        return view('admin.account.ddcollection',compact('ddaccount'));
    }

    public function collectiondd(Request $request)
    {
       // dd($request->all());
        $nextslno=ddcollection::selectRaw('max(slno) + 1 as nextslno')
        ->where('accountid',$request->accntno)->first();

        //dd($nextslno->nextslno);
        $data=[
            'AccountId'          =>  $request->accntno,
            'slno'              =>  $nextslno->nextslno,
            'damt'              =>  $request->amt,
            'userid'            =>  1,
            'ColDate'           =>  $request->doc,
        ];

        $memberdetails=accountmaster::where('accountid', $request->accntno)->first();
       // dump($memberdetails->AccountName);
        $mnextslno = atcbhd08::selectRaw('max(lslno) + 1 as nextslno')->first();
        $acct = str_pad($mnextslno->nextslno, 7, '0', STR_PAD_LEFT);
        $fnyr = explode("-", Helper::getFinYear()->finyear);
        $fyr1 = substr($fnyr[0], 2, 2);
        $voucherno = 'C/111-' . $acct . "/" . $fyr1 . "-" . $fnyr[1];
        $headid = atcbhd08::selectRaw('max(SUBSTRING_INDEX(HeadId, "-" , -1)) + 1 as nextheadid')->first();
        $nextheadid = '111-' . str_pad($headid->nextheadid, 8, 0, STR_PAD_LEFT);

        $datavoucher=[
            'HeadId'        =>  $nextheadid,
            'TType'         =>  'C',
            'VoucherNo'     =>  $voucherno,
            'Amt'           =>  $request->amt,
            'DC'            =>  'D',
            'DescId'        =>  'C0001',
            'RefType'       =>  'DC',
            'ReffId'        =>  $request->accntno."-".$nextslno->nextslno,
            'Narration'     => 'Being the amt of Daily Deposit received from '.$request->accntno,
            'IntNo'         =>  0,
            'finyear'       =>  Helper::getFinYear()->finyear,
            'lslno'         =>  $mnextslno->nextslno,
        ];

        $result=ddcollection::create($data);
        if($result){
            atcbhd08::create($datavoucher);
        }

        return response()->json(['success' => 'Ajax request submitted successfully','msg' => 'Deposit Successfully Collected']);
    }


    public function collectionmd(Request $request)
    {
        // dd($request->all());
        $nextslno = rdcollection::selectRaw('max(slno) + 1 as nextslno')
        ->where('accountid', $request->accntno)->first();

        //dd($nextslno->nextslno);
        $data = [
            'AccountId'          =>  $request->accntno,
            'slno'              =>  $nextslno->nextslno,
            'damt'              =>  $request->amt,
            'userid'            =>  Auth()->user()->id,
            'ColDate'           =>  $request->doc,
        ];

        $memberdetails = accountmaster::where('accountid', $request->accntno)->first();
        // dump($memberdetails->AccountName);
        $mnextslno = atcbhd08::selectRaw('max(lslno) + 1 as nextslno')->first();
        $acct = str_pad($mnextslno->nextslno, 7, '0', STR_PAD_LEFT);
        $fnyr = explode("-", Helper::getFinYear()->finyear);
        $fyr1 = substr($fnyr[0], 2, 2);
        $voucherno = 'C/111-' . $acct . "/" . $fyr1 . "-" . $fnyr[1];
        $headid = atcbhd08::selectRaw('max(SUBSTRING_INDEX(HeadId, "-" , -1)) + 1 as nextheadid')->first();
        $nextheadid = '111-' . str_pad($headid->nextheadid, 8, 0, STR_PAD_LEFT);

        $datavoucher = [
            'HeadId'        =>  $nextheadid,
            'TType'         =>  'C',
            'VoucherNo'     =>  $voucherno,
            'Amt'           =>  $request->amt,
            'DC'            =>  'M',
            'DescId'        =>  'C0001',
            'RefType'       =>  'MC',
            'ReffId'        =>  $request->accntno . "-" . $nextslno->nextslno,
            'Narration'     => 'Being the amt of Daily Deposit received from ' . $request->accntno,
            'IntNo'         =>  0,
            'finyear'       =>  Helper::getFinYear()->finyear,
            'lslno'         =>  $mnextslno->nextslno,
        ];

        $result = rdcollection::create($data);
        if ($result) {
            atcbhd08::create($datavoucher);
        }

        return response()->json(['success' => 'Ajax request submitted successfully', 'msg' => 'Deposit Successfully Collected']);
    }



    public function getacctdata(Request $request)
    {
        $ldate = date('Y-m-d H:i:s');
        $acctdata=accountmaster::where('AccountId','=',$request->t1)->first();
        if($acctdata->AType=="DD"){
            $depositamt=ddcollection::where('accountid','=', $request->t1)->orderBy('SlNo','DESC')->first();
            $amttilldate=ddcollection::selectRaw('sum(DAmt) as totalamt')->where('ColDate','<=',$ldate)
            ->where('accountid','=', $request->t1)->first();
            //dd($amttilldate);
        }else{
            $depositamt=rdcollection::where('accountid','=', $request->t1)->orderBy('SlNo','DESC')->first();
            $amttilldate=rdcollection::selectRaw('sum(DAmt) as totalamt')->where('ColDate','<=',$ldate)
            ->where('accountid','=', $request->t1)->first();
            $depositamt=rdCollection::where('accountid','=', $request->t1)->orderBy('SlNo','DESC')->first();
        }
        //dump($depositamt);
        return response()->json(array('success' => true, 'accdata' => $acctdata,'depoamt'  => $depositamt,'totamt'  =>  $amttilldate));

    }

    public function transferdata(Request $request)
    {
        //dd($request->all());
        $acctdata=accountmaster::where('AccountNo',$request->t1)->first();
       //dump($acctdata);
        return response()->json(array('success' => true, 'accdata' => $acctdata));

    }

    public function passbook(Request $request)
    {
        $account_data = collect();
        $transactions = collect();
        if($request->has("accountid")){
            $account_data=accountmaster::where('AccountId',$request->accountid)
                ->first();
            if($account_data->AType=='DD'){
                // $transactions = \DB::table("customer_transactions")
                // ->selectRaw('
                //     customer_transactions.AccountId,
                //     customer_transactions.date,
                //     customer_transactions.PTYPE,
                //     customer_transactions.amount,
                //     if(customer_transactions.PTYPE = "DEPOSIT", @running_total:=@running_total + customer_transactions.amount, @running_total:=@running_total - customer_transactions.amount) AS cumulative_sum
                // ')
                // ->join(\DB::raw("(SELECT @running_total:=0)  as r)"), 1, "=", 1)
                // ->where("AccountId", $request->accountid)
                // ->paginate(10);
                $transactions = \DB::select('
                SELECT t.date,t.PTYPE , t.amount, t.AccountId, if(t.PTYPE = "DEPOSITE", @running_total:=@running_total + t.amount, @running_total:=@running_total - t.amount) AS cumulative_sum FROM ( SELECT * FROM customer_transactions ) t JOIN (SELECT @running_total:=0) r where t.AccountId = ? ORDER BY t.date
                ', [$request->accountid]);
                // dd($transactions);
            }elseif($account_data->AType=='MD'){
    
            }
        }
        $acctdata=accountmaster::where('Status','O')->get();
        return view('admin.account.passbook',compact('acctdata', "account_data", "transactions"));
    }

    public function withdrawal(Request $request)
    {
       $acno=$request->accntno;
       $acid=$request->accntid;
       $wdate=$request->doc;
       $acctdata=accountmaster::where('AccountId','=',$acid)->first();
       //dump($request->all());
       if($acctdata->AType=="DD"){

           $data=[
                'AccountId' =>  $acid,
                'WDate'     =>  $wdate,
                'WAmt'      =>  $request->amt,
                'WBankId'   =>  $request->bankid,
                'WChqNo'    =>  $request->chqno,
                'WChqDate'  =>  $request->chqdate,
                'Atype'     =>  'DD',
                'UserId'    =>   Auth()->user()->id,
           ];
           if($request->closeac=='y'){
                $data['remarks']='Closed Account';
            }else{
                $data['remarks']='Partial Withdrawal';
            }
            if($request->transferac!=''){
                $data['AdjAccountId']=$request->transferac;
            }
           

           $result=ddwithdrawal::create($data);
           if($request->closeac=='y'){
              $accountmaster= accountmaster::where('AccountId',$acid)->first();
            $accountmaster->Status='C';
            $accountmaster->save();
           }
           if($result){
               return response()->json(array('success'  => true,'msg'   =>  'Withdrawal Successfull'));
           }
       }
       if($acctdata->AType=="MD"){

        $data=[
             'AccountId' =>  $acid,
             'WDate'     =>  $wdate,
             'WAmt'      =>  $request->amt,
             'WBankId'   =>  $request->$bankid,
             'WChqNo'    =>  $request->$chqno,
             'WChqDate'  =>  $request->$chqdate,
             'Atype'     =>  'DD',
             'UserId'    =>   Auth()->user()->id,
        ];
        if($request->closeac=='y'){
             $data['remarks']='Closed Account';
         }else{
             $data['remarks']='Partial Withdrawal';
         }
         if($request->transferac!=''){
             $data['AdjAccountId']=$request->transferac;
         }
        

        $result=mdwithdrawal::create($data);
        if($request->closeac=='y'){
           $accountmaster= accountmaster::where('AccountId',$acid)->first();
         $accountmaster->status='C';
         $accountmaster->save();
        }
        if($result){
            return response()->json(array('success'  => true,'msg'   =>  'Withdrawal Successfull'));
        }
    }

    }

    public function getacctdatamd(Request $request)
    {

        $acctdata = accountmaster::where('AccountId', '=', $request->t1)->first();
        $depositamt = rdcollection::where('accountid', '=', $request->t1)->orderBy('SlNo', 'DESC')->first();
        return response()->json(array('success' => true, 'accdata' => $acctdata, 'depoamt'  => $depositamt));
    }

    public function accountreportdd(Request $request)
    {
        //dd($request->all());

        $acctrpt=accountmaster::with(['ddcollection' => function($query){
            return $query->orderBy('ColDate','ASC');
        }])->where(['accountno'=>$request->acid,'status'=>'O'])
        ->get();

        // $acctrpt=ddcollection::with('ddcollection',function($query){
        //     return $query->orderBy('ColDate','ASC');
        // })->where(['AccountId'=>$request->acid,'status'=>'O'])
        // ->get();
        //dd($acctrpt);
        if($acctrpt){
            return view('admin.account.indivreport',compact('acctrpt'));
        }else{
            return redirect()->back()->with('error','No Data Found');
        }
    }

    public function pdfview(Request $request)

    {

        $acctrpt = ddcollection::where(['AccountId' => $request->acid])->orderBy('SlNo', 'ASC')->get();
        if ($request->has('download')) {

            $pdf = \PDF::loadView('admin.account.indivreportpdf', compact('acctrpt'));
            //return $pdf->stream('report.pdf');
            return $pdf->download('admin.account.indivreportpdf.pdf');
        }
        return view('admin.account.indivreport', compact('acctrpt'));
    }

    public function withdraw()
    {
        $accountholder = accountmaster::where('status', '=', 'O')->get();
        

        return view('admin.account.withdraw',compact('accountholder'));
    }


    public function create(Request $request)
    {
        //dd($request->all());
        $rules=[
            'acctno'        =>      'required',
            'accountopendt' =>      'required',
            'memid'         =>      'required',
            'amount'        =>      'required',
        ];

        $customMessages = [
            'required' => 'The :attribute field can not be blank.'
        ];

        $validator=Validator::make($request->all(),$rules, $customMessages);

        if($validator->fails()){
            return redirect()->back()->withErrors($validator);
        }

        //find account id from accountmaster
        $nextaccountid=accountmaster::selectRaw('max(accountid) + 1 as nextaccntid')->first();
        $acno=$request->acctno;
        $memname= \App\Helpers\Helper::getmembername($request->memid);
        $dataaccntmaster=[
            'accountid'     =>  $nextaccountid->nextaccntid,
            'AccountNo'     =>  $acno,
            'Atype'         =>  $request->deposittype,
            'AccountName'   =>  $memname,
            'MemberId'      =>  $request->memid,
            'intrate'       =>  $request->rate,
            'DepositAmt'    =>  $request->amount,
            'AdmissionDate' =>  date('Y-m-d',strtotime($request->accountopendt)),
            'pan'           =>  $request->panno,
            'gender'        =>  $request->gender,
            'IntroducerName'=>  $request->introducer,
            'IntroducerACNo'=>  $request->intacno,
            'EntryDate'     =>  $request->doe,
            'userid'        =>  Auth()->user()->id,

        ];
        accountmaster::create($dataaccntmaster);

        //find transaction id from ddcollection against the account no
        $nextd_id=ddcollection::selectRaw('max(slno) + 1 as nextddslno')->where('Accountid','=', $nextaccountid)->first();
        if($nextd_id){
                $nextd_id->nextddslno=1;
        }
            $insddcollection=[
            'accountid'     =>  $nextaccountid->nextaccntid,
            'SlNo'          =>  $nextd_id->nextddslno,
            'ColDate'       =>  date('Y-m-d', strtotime($request->accountopendt)),
            'DAmt'          =>  $request->amount,
            'UserId'        =>  Auth()->user()->id,
            ];

        ddcollection::create($insddcollection);

        $mnextslno = atcbhd08::selectRaw('max(lslno) + 1 as nextslno')->first();
        $acct = str_pad($mnextslno->nextslno, 7, '0', STR_PAD_LEFT);
        $fnyr = explode("-", Helper::getFinYear()->finyear);
        $fyr1 = (substr($fnyr[0], 2, 2));

        $voucherno = 'C/111-' . $acct . "/" . $fyr1 . "-" . $fnyr[1];
        $headid = atcbhd08::selectRaw('max(SUBSTRING_INDEX(HeadId, "-" , -1)) + 1 as nextheadid')->first();
        $nextheadid = '111-' . str_pad($headid->nextheadid, 8, 0, STR_PAD_LEFT);


        $datains = [
            'HeadId'        =>  $nextheadid,
            'TType'         =>  'C',
            'VoucherNo'     =>  $voucherno,
            'Amt'           =>  $request->amount,
            'DC'            =>  $request->deposittype,
            'DescId'        =>  'C0001',
            'RefType'       =>  'C',
            'ReffId'        =>  $nextaccountid->nextaccntid."-".$nextd_id->nextddslno,
            'Narration'     => 'Being the amt of Daily Deposit received from '.$memname,
            'IntNo'         =>  0,
            'finyear'       =>  Helper::getFinYear()->finyear,
            'lslno'         =>  $mnextslno->nextslno,
        ];

        atcbhd08::create($datains);

        return redirect()->back()->with('success', "Account Successfully opened");
    }
}
