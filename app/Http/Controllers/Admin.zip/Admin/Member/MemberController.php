<?php

namespace App\Http\Controllers\Admin\Member;

use App\Helpers\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\members\memberswithgroup;
use App\Models\members\memberswithqualification;
use App\Models\Admin\membermaster;
use App\Models\Admin\memberdocument;
use App\Models\Admin\groupmaster;
use App\Models\Admin\atcbhd08;
use App\Models\members\eomaster;
use App\Models\Admin\eogroup;
use App\Models\Admin\feemaster;
use App\Models\Admin\shares;
use App\Models\misc\finyear;
use Illuminate\Support\Facades\Validator;
use DB;

class MemberController extends Controller
{
    public function index()
    {
        $memrecs = memberswithgroup::query();
        $memrecs->when((request("t") && request("t1")), function($query){
            $query->whereBetween('groupid', [request("t"), request("t1")]);
        });

        $memrecs->when(request("memid"),function($query){
            $query->where('memberid','=', request("memid"))->first();
        });


        $memrecs = $memrecs->orderBy('MemberId','ASC')->withTrashed()->paginate(20);
        return view('admin.member.index',compact('memrecs'));
    }

    public function delete(Request $request)
    {

        $id = $request->memid;
        $delrec = membermaster::where("MemberId", $id)->first();
        if (!$delrec) {
            abort(404);
        }
        $delrec->delete();
        return redirect()->back()->with("success", "Successfully deleted.");
    }

    public function view(Request $request)
    {
        $memid=$request->memid;
        $memdetails=membermaster::where("memberid",'=',$memid)->first();

        return View('admin.member.view',compact('memdetails'));
    }

    public function edit(Request $request)
    {
        $eomember=eomaster::get();
        $id = $request->memid;
        $submit = 'Update';
        $finyr = finyear::where('status', 1)->first();

        $memid= membermaster::selectRaw('max(memberid)+1 as memberid')->first();
        $feedetails=feemaster::where('session','=',$finyr->finyear)->get();
        $editprofile = membermaster::where("MemberId", $id)->first();
        $memberdocument=memberdocument::where('member_id',$id)->first();
        $splitName = explode(' ', $editprofile->MemberName, 2); // Restricts it to only 2 values, for names like Billy Bob Jones

        $first_name = $splitName[0];
        $last_name = !empty($splitName[1]) ? $splitName[1] : '';
        $employee = DB::table('eo_group')->where('EOId',$editprofile->MemberId)->first();

        return view('admin.member.edit',compact('editprofile','eomember','submit','employee','first_name','last_name','memberdocument','feedetails'));
    }

    public function update(Request $request,$member_id)
    {

        $eomember=eomaster::get();
        $id = $request->member_id;
        $submit = 'Update';

        $editprofile = membermaster::where("MemberId", $id)->first();
        $data=[

            'MemSrNo'       =>  $request->membersrno,
            'MemberNo'      =>  $request->groupno.$request->membersrno,

            'AdmissionDate' =>  date('Y-m-d'),

            'TargetNo'      =>  $request->targetno,
            'MemberName'    =>   $request->txtfname.' '.$request->txtlname,
            'Gender'        =>  $request->gender,
            'MemAge'        =>  $request->age,
            'MemberDOB'     =>  $request->dob,
            'Caste'         =>  $request->mstatus,
            'Rlgn'          =>  $request->mreligion,
            'QualificationId'=> $request->mqualification,
            'OccupationId'  =>  $request->occupation,
            'ResAdd1'       =>  $request->txtpresenthouseno,
            'ResAdd2'       =>  $request->txtroadname,

            'NomName'       =>   $request->nominee,
            'NomRelationId' =>  $request->nomrelation,
            'adhaar_card_no'=>$request->adhaar_card_no??'',
            'driving_licence_no'=>$request->driving_licence_no??'',
            'pancard_no'=>$request->pancard_no??'',
            'ration_card_no'=>$request->ration_card_no??'',
            'voter_card_no'=>$request->voter_card_no??'',


        ];

        $editprofile->update($data);

         return redirect()->back()->with("success", "Successfully updated.");


    }
    public function addmember(Request $request)
    {

        $eomember=eomaster::all();
        $submit = 'Add';
        $finyr = finyear::where('status', 1)->first();

        $memid= membermaster::selectRaw('max(memberid)+1 as memberid')->first();
        $feedetails=feemaster::where('session','=',$finyr->finyear)->get();
       //dd($feedetails[1]->feeid);
        return view("admin.member.addmember",compact('eomember','submit', 'memid', 'feedetails'));
    }

    public function savemember(Request $request)
    {
        $rules=[
            'dob'           => 'required|date',
            'nos'           => 'required|numeric',
            // 'membersrno'   => 'required|numeric',
        ];
        $checkvalid=Validator::make($request->all(),$rules);

        if(!$checkvalid->fails()){
            $feeadmission=feemaster::where('feeid','=',1)->first();
            $feesale=feemaster::where('feeid', '=', 2)->first();

            $nextmemid = membermaster::selectRaw("max(MemberId) +1 as nextmemid,max(id) + 1 as nextid")->first();
            $grpid=groupmaster::select('groupid')->where('GroupCode','=', $request->groupno)->first();


            if($request->hasFile('memberphoto')){

                $path1="";
                $path = public_path() . '/images/memberphoto/';

                $file=$request->file('memberphoto');
                $imageName = date('dmyhis') . 'memberphoto.' . $file->getClientOriginalExtension();
               //dd( $imageName);
                $file->move($path, $imageName);
                $path1 = url('/') . '/images/memberphoto/' . $imageName;


            }
            if ($request->hasFile('signature')) {
                $path2="";
                $path = public_path() . '/images/signature/';
                $file=$request->file('signature');
                $imageName = date('dmyhis') . 'signature.' . $file->getClientOriginalExtension();
                $file->move($path, $imageName);
                $path2 = url('/') . '/images/signature/' . $imageName;

            }
            if ($request->hasFile('adhaar')) {
                $path3 = "";
                $path = public_path() . '/images/adhaar/';
                $file=$request->file('adhaar');
                $imageName = date('dmyhis') . 'adhaar.' . $file->getClientOriginalExtension();
                $file->move($path, $imageName);
                $path3 = url('/') . '/images/adhaar/' . $imageName;

            }

            if ($request->hasFile('votercard')) {
                $path4="";
                $path = public_path() . '/images/votercard/';
                $file=$request->file('votercard');
                $imageName = date('dmyhis') . 'votercard.' . $file->getClientOriginalExtension();
                $file->move($path, $imageName);
                $path4 = url('/') . '/images/votercard/' . $imageName;
            }

            if ($request->hasFile('passport')) {
                $path5="";
                $path = public_path() . '/images/passport/';
                $file=$request->file('passport');
                $imageName = date('dmyhis') . 'passport.' . $file->getClientOriginalExtension();
                $file->move($path, $imageName);
                $path5 = url('/') . '/images/passport/' . $imageName;
            }

            if ($request->hasFile('ration')) {
                $path6="";
                $path = public_path() . '/images/ration/';
                $file=$request->file('ration');
                $imageName = date('dmyhis') . 'ration.' . $file->getClientOriginalExtension();
                $file->move($path, $imageName);
                $path6 = url('/') . '/images/ration/' . $imageName;

            }

            if ($request->hasFile('driving')) {
                $path7="";
                $path = public_path() . '/images/driving/';
                $file=$request->file('driving');
                $imageName = date('dmyhis') . 'driving.' . $file->getClientOriginalExtension();
                $file->move($path, $imageName);
                $path7 = url('/') . '/images/driving/' . $imageName;

            }

            if ($request->hasFile('pancard')) {
                $path7="";
                $path = public_path() . '/images/pancard/';
                $file=$request->file('pancard');
                $imageName = date('dmyhis') . 'pancard.' . $file->getClientOriginalExtension();
                $file->move($path, $imageName);
                $path7 = url('/') . '/images/pancard/' . $imageName;

            }

                //dd($path1);
            //dd($nextmemid->nextid);
            $data=[
                'id'            =>  $nextmemid->nextid,
                'MemberId'      =>  $nextmemid->nextmemid,
                'MemSrNo'       =>  $request->membersrno,
                'MemberNo'      =>  $request->groupno.$request->membersrno,
                'GroupId'       =>  $grpid->groupid,
                'AdmissionDate' =>  date('Y-m-d'),
                'Adminfee'      =>  $feeadmission->amount,
                'TargetNo'      =>  $request->targetno,
                'MemberName'    =>  $request->txtfname.' '.$request->txtlname,
                'Gender'        =>  $request->gender,
                'MemAge'        =>  $request->age,
                'MemberDOB'     =>  $request->dob,
                'Caste'         =>  $request->mcaste,
                'Rlgn'          =>  $request->mreligion,
                'QualificationId'=> $request->mqualification,
                'OccupationId'  =>  $request->occupation,
                'ResAdd1'       =>  $request->txtpresenthouseno,
                'ResAdd2'       =>  $request->txtroadname,
                'SalebleFee'    =>  $feesale->amount,
                'NomName'       =>  $request->nominee,
                'NomRelationId' =>  $request->nomrelation,
                'HouseType'     =>  $request->assettype,
                'Spouce'        =>  $request->spouse,
                'SpouceAge'     =>  $request->spage,
                'BankName'      =>  $request->bank,
                'acno'          =>  $request->bankaccountno,
                'YearlyIncome'  =>  $request->earnings,
                'NomAge'        =>  $request->nomage,
                'NomSex'        =>  $request->nomineegender,
                'NomDOB'        =>  $request->nomdob,
                'PerAdd1'       =>  $request->txtpermahouseno,
                'PerAdd2'       =>  $request->txtpermaroadname,
                'introducer_name'=>$request->introducer_name,
                'introducer_membership_no'=>$request->introducer_membership_no,
                'introducers_account_no'=>$request->introducers_account_no,
                'adhaar_card_no'=>$request->adhaar_card_no??'',
                'driving_licence_no'=>$request->driving_licence_no??'',
                'pancard_no'=>$request->pancard_no??'',
                'ration_card_no'=>$request->ration_card_no??'',
                'voter_card_no'=>$request->voter_card_no??'',
 ];

            membermaster::create($data);

            $insmemdocument=[
                'member_id'     =>     $nextmemid->nextmemid,
                'photo'         =>      $path1??null,
                'signature'     =>      $path2??null,
                'pancard'       =>      $path8??null,
                'adhaar'        =>      $path3??null,
                'voter'         =>      $path4??null,
                'passport'      =>      $path5??null,
                'ration'        =>      $path6??null,
                'drivinglic'    =>      $path7??null,
            ];

            memberdocument::create($insmemdocument);


            //insert into atcbhd08
            $mnextslno= atcbhd08::selectRaw('max(lslno) + 1 as nextslno')->first();
            $acct = str_pad($mnextslno->nextslno, 7, '0', STR_PAD_LEFT);
            $fnyr=explode("-",Helper::getFinYear()->finyear);
            $fyr1=(substr($fnyr[0],2,2));

            $voucherno = 'C/111-'.$acct."/".$fyr1."-".$fnyr[1];
            $headid= atcbhd08::selectRaw('max(SUBSTRING_INDEX(HeadId, "-" , -1)) + 1 as nextheadid')->first();
            $nextheadid='111-'. str_pad($headid->nextheadid,8,0, STR_PAD_LEFT);

            $datains=[
                'HeadId'        =>  $nextheadid,
                'TType'         =>  'C',
                'VoucherNo'     =>  $voucherno,
                'Amt'           =>  $feeadmission->amount,
                'DC'            =>  'D',
                'DescId'        =>  'C0001',
                'RefType'       =>  'M',
                'ReffId'        =>  $nextmemid->nextmemid,
                'Narration'     => 'Being the amt of admission fee received from'.$request->memtype.",".$request->txtfname.' '.$request->txtlname,
                'IntNo'         =>  0,
                'lslno'         =>  $mnextslno->nextslno,
            ];

            atcbhd08::create($datains);

            $mnextslno = atcbhd08::selectRaw('max(lslno) + 1 as nextslno')->first();
            $acct = str_pad($mnextslno->nextslno, 7, '0', STR_PAD_LEFT);
            $fnyr = explode("-", Helper::getFinYear()->finyear);
            $fyr1 = (substr($fnyr[0], 2, 2));

            $voucherno = 'C/111-' . $acct . "/" . $fyr1 . "-" . $fnyr[1];
            $headid = atcbhd08::selectRaw('max(SUBSTRING_INDEX(HeadId, "-" , -1)) + 1 as nextheadid')->first();
            $nextheadid = '111-' . str_pad($headid->nextheadid, 8, 0, STR_PAD_LEFT);

            $datains = [
                'HeadId'        =>  $nextheadid,
                'TType'         =>  'C',
                'VoucherNo'     =>  $voucherno,
                'Amt'           =>  $feesale->amount,
                'DC'            =>  'D',
                'DescId'        =>  'C0001',
                'RefType'       =>  'M',
                'ReffId'        =>  $nextmemid->nextmemid,
                'Narration'     => 'Being the amt of admission fee received from' . $request->memtype . "," . $request->txtfname . ' ' . $request->txtlname,
                'IntNo'         =>  0,
                'lslno'         =>  $mnextslno->nextslno,
            ];
            atcbhd08::create($datains);
            //dd($nextmemid->nextmemid);
            if($request->nos){
                $mnextslno = atcbhd08::selectRaw('max(lslno) + 1 as nextslno')->first();
                $acct = str_pad($mnextslno->nextslno, 7, '0', STR_PAD_LEFT);
                $fnyr = explode("-", Helper::getFinYear()->finyear);
                $fyr1 = (substr($fnyr[0], 2, 2));

                $voucherno = 'C/111-' . $acct . "/" . $fyr1 . "-" . $fnyr[1];
                $headid = atcbhd08::selectRaw('max(SUBSTRING_INDEX(HeadId, "-" , -1)) + 1 as nextheadid')->first();
                $nextheadid = '111-' . str_pad($headid->nextheadid, 8, 0, STR_PAD_LEFT);

                $datashare=[
                    'HeadId'        =>  $nextheadid,
                    'TType'         =>  'C',
                    'VoucherNo'     =>  $voucherno,
                    'Amt'           =>  $request->nos*100,
                    'DC'            =>  'D',
                    'DescId'        =>  'C0001',
                    'RefType'       =>  'M',
                    'ReffId'        =>  $nextmemid->nextmemid,
                    'Narration'     => 'Being the amt of Share received from'.$request->memtype.",".$request->txtfname . ' ' . $request->txtlname,
                    'IntNo'         =>  0,
                    'lslno'         =>  $mnextslno->nextslno,
                 ];

                atcbhd08::create($datashare);

                $insshare = [
                    'MemberId'      =>      $nextmemid->nextmemid,
                    'MemSrNo'       =>      $request->membersrno,
                    'MemberNo'      =>      $request->groupno . $request->membersrno,
                    'shares'        =>      $request->nos,
                    'shareamount'   =>      $request->nos * 100,
                    'voucher_no'    =>      $voucherno,

                ];

                shares::create($insshare);
            }

            return view('admin.member.savedmember')->with('success','Member Successfully added');

        }else{
            return redirect()->back()->withErrors($checkvalid);

        }



    }
    public function ddmember(Request $request)
    {
        $gr1=$request->t;
        $gr2=$request->t1;
        $ddmember=memberswithgroup::whereBetween('groupid',[$gr1,$gr2])->get();
        if(!$ddmember->isEmpty())
            return response()->json(array('success'=>true,'memberdata'=>$ddmember),200);
        else
            return response()->json(array('success' => false), 200);
    }

    public function getmember(Request $request)
    {
        $memid=$request->member;

        $ddmember = membermaster::where('MemberId', $memid)->first();
        //dump($ddmember);
        $relation = Helper::getrelation($ddmember->NomRelationId);
        $ddmember['relation']= isset($relation->relation) ? $relation->relation : "NA";
        //dd($ddmember['relation']->);
        if ($ddmember)
            return response()->json(array('success' => true, 'memberdata' => $ddmember), 200);
        else
            return response()->json(array('success' => false), 200);

    }

    public function getMemberBySerialNo(Request $request){
        $serial_no=$request->serial_no;
        $member_details = membermaster::where('MemSrNo', $serial_no)->first();
        if ($member_details)
        return response()->json(array('success' => true, 'memberdata' => $member_details), 200);
    else
        return response()->json(array('success' => false), 200);

    }
    public function geteo(request $request)
    {
        $eomember = eogroup::where('EOId', '=', $request->member)->first();
        if ($eomember) {
            return response()->json(array('success' => true, 'memberdata' => $eomember), 200);
        } else
            return response()->json(array('success' => false), 200);

    }




}
